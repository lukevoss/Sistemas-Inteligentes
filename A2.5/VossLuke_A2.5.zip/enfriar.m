function e=enfriar(T,i)

%e=T/(i+1); %%cauchy
e=0.8*T; %% exponencial